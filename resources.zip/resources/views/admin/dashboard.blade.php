@extends('admin.master')

@section('content')
<div class="row">
  
</div>
@endsection