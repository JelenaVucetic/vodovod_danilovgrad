@extends('layouts.master')

@section('content')
<link rel="stylesheet" href="/css/about.css">

        <div class="about">
            <div class="row">
                <div class="col-l-12 col-xl-12 col-sm-12 col-xs-12 mb-5">
                  <div class="card">
                    <div class="card-header">
                     <h3>Menadžment</h3>   
                      </div>
                    <div class="card-body">
                      <h5 class="card-title">Izvršni direktor</h5>
                      <p class="card-text">
                        Predrag Kalezić, dipl.pravnik<br>
                        tel/fax: 020/811-550<br>
                        e-mail: predrag.kalezic@vikdg.me <br>

                      </p>
                    </div>
                  </div>
                </div>
                <div class="col-l-12 col-xl-12 col-sm-12 col-xs-12">
                    <div class="card">
                      <div class="card-header">
                       <h3>Odbor direktora</h3>   
                        </div>
                      <div class="card-body">
                        <h5 class="card-title">Odbor direktora DOO „Vodovod i kanalizacija“ Danilovgrad čine 5 članova i to:</h5>
                        <p class="card-text">
                            1.	Mr Goran Zeković, Predsjednik Odbora direktora<br>
                            2.	Vukota Stanišić, član<br>
                            3.	Dario Đuričković, član<br>
                            4.	Dražen Kalezić, član<br>
                            5.	Ljubomir Stajović, član
                            <br>
  
                        </p>
                      </div>
                    </div>
                  </div>
              </div>
        </div>
            @endsection
