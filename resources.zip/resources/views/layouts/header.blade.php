
<header class="header sticky-top">
    <div class="nav-mobile"><a id="nav-toggle" href="#!"><span></span></a></div>
    <div>
        <a href="/"><img class="hedimg"src="/images/Component3–1.png" alt="" id="logo"></a>
 

        <nav>
            <ul class="nav-list">
    <div class="header-content">
      
        <div class="header-left">
         
            <div>
             <h6><a href="/">Naslovna</a></h6>   
            </div>
            <div>
             <h6> <a href="/about">O nama</a></h6>  
            </div>
            <div>
                <h6> <a href="/obavestenja">Obavještenja</a></h6>  
               </div>
            <div>
                <h6><a href="/warrants-all">Putni nalozi</a></h6> 
             </div>
             <div>
                <h6><a href="/notices-all">Dokumentacija</a></h6> 
             </div>
        </div>
        <div class="header-right">
            <div>
               <img src="/images/iconfinder_phone_216352.svg" alt="">
               <h6><a href="tel:069095581">020 / 811 - 550</a></h6>
            </div>
            <div>
                <img src="/images/Page-1.svg" alt="">
                <h6><a href="mailto:vik@danilovgrad.me">vik@danilovgrad.me</a></h6>
            </div>
         
        </div>
        <div class="search">
            <img src="/images/search_1_.svg" alt="">
            <select class="js-example-basic-multiple" name="states[]" multiple="multiple">
                <option value="AL">Alabama</option>
                  ...
                <option value="WY">Wyoming</option>
              </select>
        </div>
    </div>
</ul>
</nav>

</header>