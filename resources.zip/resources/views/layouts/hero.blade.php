<div class="hero">
    <div class="hero-content">
        <div class="hero-left">
            <h1>Vodovod i kanalizacija</h1>
            <h2>Danilovgrad</h2>
        </div>

    </div>
    
</div>