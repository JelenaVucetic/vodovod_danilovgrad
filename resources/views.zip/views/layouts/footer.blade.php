<footer >  










    <div class="footerD">
        <div class="footer-content row">
            <div class="footer-left col-l-3 col-xl-3 col-sm-12 col-xs-12 justify-content-center mt-3">
                    <h4 class="my-3">DOKUMENTACIJA</h4>
                    <p>   <a href="/obavestenja">Obavještenja</a></p>
                        <p>   <a href="/warrants-all">Putni Nalozi</a></p>
                            <p>  <a href="/notices-all">Dokumentacija</a></p>
      
               <div class="footer-logo">
                   <img src="/images/VIK-DG-Logo White.png" alt="">
               </div>
            </div>
            <div class="footer-middle col-l-3 col-xl-3 col-sm-12 col-xs-12 justify-content-center mt-3">
                <h4 class="my-3">INFORMACIJE</h4>
                <p> <span>Adresa:</span> Ul. Jefta - Čaja Šćepanovića b.b. Danilovgrad</p>
                <p> <span>Telefon:</span> <a href="tel:020 81 15 50 ">020 81 15 50 </a></p>
                <p> <span>Email adresa:</span> <a href="mailto:jkzpdanilovgrad@t-com.me">jkzpdanilovgrad@t-com.me</a></p>

            {{--     <div>
                    <ul>
                        <li>
                            <a href="">Facebook</a>
                        </li>
                        <li>
                            <a href="">Instagram</a>
                        </li>
                        <li>
                            <a href="">Twitter</a>
                        </li>
                    </ul>
                </div> --}}

            </div>
            <div class="footer-right col-l-3 col-xl-3 col-sm-12 col-xs-12 justify-content-center mt-3">
                <h4 class="my-3">KORISNI LINKOVI</h4>
                <p>     <a href="https://www.danilovgrad.me/" target="new">Danilovgrad</a></p>
                    <p>    <a href="http://www.gov.me/naslovna">Vlada Crne Gore</a></p>
                        <p>    <a href="http://www.mrt.gov.me/ministarstvo">Ministarstvo Održivog razvoja i turizma</a></p>
                            <p>    <a href="https://www.privrednakomora.me/">Privredna komora Crne Gore</a></p>
            </div>
        </div>

    </div>
    <div class="footer-bottom mx-5 ">
            <div class="footer-bottom-content">
                <div>
                    <p>Sva prava zadržana - VIK DANILOVGRAD</p>
                </div>
                <div>
                    <p>Made by <a href="https://qqriq.me/">QQRIQ</a></p>
                </div>
            </div>

    </div>
</footer>
