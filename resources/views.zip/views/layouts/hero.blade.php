<div class="hero">
    <div class="hero-content">
        <div class="hero-left">
            <h1>DOO Vodovod i kanalizacija</h1>
            <h2>Danilovgrad</h2>
        </div>

    </div>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>

    .header{
        position: absolute !important;
        width: 100%;
        top: 0;
    }
</style>
      <div id="myCarousel" class="carousel slide " data-ride="carousel" data-interval="10000">
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
          <div class="item active">
            <img src="/images/Cover-slika-2.jpg" class="sliderSlika" alt="Los Angeles" style="width:100%;">
          </div>
         {{--    <div class="item mobileKar">
            <img src="/images/coverphone.png" class="sliderSlika" alt="Chicago" style="width:100%;">
          </div>  --}}
          <div class="item ">
            <img src="/images/Cover-slika-3.jpg" class="sliderSlika" alt="Chicago" style="width:100%;">
          </div>

        </div>
    
        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
          <span class="glyphicon glyphicon-chevron-left"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
          <span class="glyphicon glyphicon-chevron-right"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>

   
</div>